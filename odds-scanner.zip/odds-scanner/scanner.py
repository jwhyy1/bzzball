#!/usr/bin/env python3
"""
Odds scanner + paper-trade logger, designed to be run on a schedule by Claude Cowork.

Each run:
  1. Loads request budget state (won't exceed the daily cap)
  2. Pulls fixtures for the tracked tournaments
  3. Prioritises fixtures by proximity to start (odds move most in the run-up)
  4. Fetches odds for the top-priority fixtures only
  5. De-vigs each book, builds a median consensus fair price
  6. Flags arbitrage and +EV opportunities
  7. Sizes positions off current capital in the ledger
  8. Appends them to the Trade Blotter tab of the workbook

Deliberately does NOT settle bets - results aren't in the odds feed.

Usage:
    export ODDSPAPI_KEY="your-key"
    python scanner.py                    # normal run
    python scanner.py --dry-run          # scan and report, write nothing
    python scanner.py --status           # show budget + open positions
"""

import os
import sys
import json
import time
import argparse
import datetime as dt
from statistics import median
from urllib.request import urlopen, Request
from urllib.error import HTTPError, URLError

# ----------------------------------------------------------------- config
VERSION = "2.0.0"          # all tunables configurable via config.json
BASE = "https://api.oddspapi.io/v4"

# Config is read from config.json sitting next to this script. Environment
# variables still work as an override, but the file is the normal route -
# it avoids shell dialect differences between Windows, macOS and Linux.
_HERE = os.path.dirname(os.path.abspath(__file__))
_CONFIG_PATH = os.path.join(_HERE, "config.json")


def _load_config():
    cfg = {}
    try:
        with open(_CONFIG_PATH, encoding="utf-8") as f:
            cfg = json.load(f)
    except FileNotFoundError:
        pass
    except json.JSONDecodeError as e:
        print(f"[!] config.json has a syntax error on line {e.lineno}: {e.msg}")
        print("[!] Check for a missing comma, quote, or bracket.")
        sys.exit(1)
    return cfg


_CFG = _load_config()


def _setting(key, default=None):
    """Environment variable wins, then config.json, then the default."""
    env = os.environ.get(key)
    if env not in (None, ""):
        return env
    return _CFG.get(key, default)


API_KEY = _setting("ODDSPAPI_KEY", "")

_default_ledger = os.path.join(_HERE, "paper-trading-ledger.xlsx")
_default_state = os.path.join(_HERE, "scanner-state.json")
LEDGER = _setting("LEDGER_PATH") or _default_ledger
STATE = _setting("STATE_PATH") or _default_state

# Tournaments to track: {"label": tournamentId}. Populate via --list-tournaments.
_tracked = _setting("TRACKED_TOURNAMENTS", {})
if isinstance(_tracked, str):
    try:
        _tracked = json.loads(_tracked or "{}")
    except json.JSONDecodeError:
        _tracked = {}
TRACKED = _tracked

DAILY_REQUEST_BUDGET = int(_setting("DAILY_BUDGET", 8))
MIN_BOOKS_FOR_CONSENSUS = int(_setting("MIN_BOOKS", 3))
RESCAN_COOLDOWN_MIN = int(_setting("RESCAN_COOLDOWN_MIN", 45))
SKIP_INSIDE_MIN = int(_setting("SKIP_INSIDE_MIN", 20))       # too late to place a bet
PRIORITY_WINDOW_HRS = float(_setting("PRIORITY_WINDOW_HRS", 6))
SETTLE_DELAY_HRS = float(_setting("SETTLE_DELAY_HRS", 3))
SCAN_RESERVE = int(_setting("SCAN_RESERVE", 2))
MIN_REQUEST_INTERVAL = float(_setting("MIN_REQUEST_INTERVAL", 2.0))   # seconds between API calls
MAX_RETRIES = 3               # retries when rate limited
RETRY_BACKOFF_SECS = 5        # first backoff; doubles each retry

# Position sizing (mirrors the Assumptions tab)
ARB_PCT = float(_setting("ARB_STAKE_PCT", 0.10))
ARB_CAP = float(_setting("ARB_STAKE_CAP", 750.0))
KELLY_FRACTION = float(_setting("KELLY_FRACTION", 0.50))
EV_CAP_PCT = float(_setting("EV_STAKE_CAP_PCT", 0.05))
MAX_EXPOSURE_PCT = float(_setting("MAX_EXPOSURE_PCT", 0.40))
SLIPPAGE = float(_setting("SLIPPAGE", 0.005))
STARTING_CAPITAL = float(_setting("STARTING_CAPITAL", 5000.0))

# Fee model - see fees.html for sourcing
EXCHANGE_RATES = {"betfair": 0.05, "smarkets": 0.02, "betdaq": 0.02, "matchbook": 0.015}
PREDICTION_COEFF = {"kalshi": 0.07, "polymarket": 0.05}

BM_META = {
    "betfair-ex": ("Betfair Exchange", "exchange"), "smarkets": ("Smarkets", "exchange"),
    "matchbook": ("Matchbook", "exchange"), "betdaq": ("Betdaq", "exchange"),
    "kalshi": ("Kalshi", "prediction"), "polymarket": ("Polymarket", "prediction"),
    "pinnacle": ("Pinnacle", "sportsbook"), "bet365": ("Bet365", "sportsbook"),
    "williamhill": ("William Hill", "sportsbook"), "unibet": ("Unibet", "sportsbook"),
    "betway": ("Betway", "sportsbook"), "sky-bet": ("Sky Bet", "sportsbook"),
    "ladbrokes": ("Ladbrokes", "sportsbook"), "coral": ("Coral", "sportsbook"),
    "paddy-power": ("Paddy Power", "sportsbook"), "betvictor": ("BetVictor", "sportsbook"),
    "888sport": ("888sport", "sportsbook"), "betfred": ("Betfred", "sportsbook"),
    "draftkings": ("DraftKings", "sportsbook"), "boylesports": ("BoyleSports", "sportsbook"),
}


def log(msg, kind="info"):
    mark = {"ok": "[+]", "err": "[!]", "info": "[.]"}.get(kind, "[.]")
    print(f"{mark} {msg}", flush=True)


# ----------------------------------------------------------------- state
def load_state():
    try:
        with open(STATE) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {"budget": {}, "last_scan": {}, "logged": []}


def save_state(s):
    with open(STATE, "w") as f:
        json.dump(s, f, indent=2)


def today_key():
    return dt.date.today().isoformat()


def budget_left(state):
    return max(0, DAILY_REQUEST_BUDGET - state["budget"].get(today_key(), 0))


def spend(state, n=1):
    state["budget"][today_key()] = state["budget"].get(today_key(), 0) + n


# ----------------------------------------------------------------- api
def get(path, state, _attempt=1):
    if not API_KEY:
        raise RuntimeError(
            "No API key found. Open config.json and put your key in ODDSPAPI_KEY.")
    if API_KEY.strip() in ("paste-your-key-here", "your-key-goes-here"):
        raise RuntimeError(
            "config.json still contains the placeholder key. Replace it with your real one.")

    _throttle()

    sep = "&" if "?" in path else "?"
    url = f"{BASE}{path}{sep}apiKey={API_KEY}"
    req = Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) odds-scanner/" + VERSION,
        "Accept": "application/json",
    })
    try:
        with urlopen(req, timeout=30) as r:
            data = json.loads(r.read().decode())
    except HTTPError as e:
        body = ""
        try:
            body = e.read().decode()[:300]
        except Exception:
            pass
        # Rate limited: back off and retry rather than burning the rest of the run
        if e.code == 429 and _attempt <= MAX_RETRIES:
            wait = RETRY_BACKOFF_SECS * (2 ** (_attempt - 1))
            log(f"rate limited - waiting {wait}s then retrying ({_attempt}/{MAX_RETRIES})", "info")
            time.sleep(wait)
            return get(path, state, _attempt + 1)
        raise RuntimeError(_explain_http_error(e.code, path, body)) from None
    except URLError as e:
        raise RuntimeError(
            f"Could not reach the API ({e.reason}). Check your internet connection, "
            f"or whether a firewall or VPN is blocking Python.") from None
    spend(state)
    return data


_last_request_at = [0.0]


def _throttle():
    """Keep a minimum gap between every API call, wherever it's made from."""
    gap = time.time() - _last_request_at[0]
    if gap < MIN_REQUEST_INTERVAL:
        time.sleep(MIN_REQUEST_INTERVAL - gap)
    _last_request_at[0] = time.time()


def _explain_http_error(code, path, body=""):
    """Turn an HTTP status into something actionable."""
    detail = f" Server said: {body.strip()}" if body.strip() else ""
    if code in (401, 403):
        return (
            f"HTTP {code} — the API rejected the request.{detail}\n"
            "        Most likely one of:\n"
            "          1. The key in config.json is wrong, expired, or revoked.\n"
            "             Log in at oddspapi.io and confirm it is still active.\n"
            "          2. Your monthly 250-request allowance is used up.\n"
            "             Check your usage on the oddspapi.io dashboard.\n"
            "          3. This endpoint is not included on the free tier.\n"
            "        Run:  python scanner.py --test-key   for a direct check."
        )
    if code == 429:
        return ("HTTP 429 — rate limited. You are sending requests too quickly, "
                "or have hit your monthly allowance. Wait a few minutes and retry.")
    if code == 404:
        return f"HTTP 404 — endpoint not found: {path}. The API version may have changed."
    if 500 <= code < 600:
        return f"HTTP {code} — the API is having problems at their end. Try again shortly."
    return f"HTTP {code} on {path}.{detail}"


def test_key():
    """Make one minimal request and report precisely what happened."""
    print(f"Testing your API key...  (scanner.py {VERSION})\n")
    if not API_KEY:
        print("  No key found in config.json.")
        return
    print(f"  Key in config.json : {API_KEY[:8]}...{API_KEY[-4:]}  ({len(API_KEY)} chars)")
    if API_KEY.strip() in ("paste-your-key-here", "your-key-goes-here"):
        print("  This is still the placeholder — paste your real key into config.json.")
        return

    url = f"{BASE}/sports?language=en&apiKey={API_KEY}"
    print(f"  Calling            : {BASE}/sports\n")
    req = Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) odds-scanner/" + VERSION,
        "Accept": "application/json",
    })
    try:
        with urlopen(req, timeout=30) as r:
            payload = json.loads(r.read().decode())
        n = len(payload) if isinstance(payload, list) else "some"
        print(f"  SUCCESS — the key works. Returned {n} sports.")
        print("  You can carry on with step 2.6.")
    except HTTPError as e:
        body = ""
        try:
            body = e.read().decode()[:300]
        except Exception:
            pass
        print(f"  FAILED — {_explain_http_error(e.code, '/sports', body)}")
    except URLError as e:
        print(f"  FAILED — could not reach the server: {e.reason}")
        print("  Check your internet connection, firewall, or VPN.")


# ----------------------------------------------------------------- maths
def implied(o):
    return 1.0 / o if o else None


def devig_pair(o1, o2):
    """Strip the bookmaker margin from a two-way price."""
    if not o1 or not o2:
        return None
    i1, i2 = 1 / o1, 1 / o2
    tot = i1 + i2
    return (i1 / tot, i2 / tot)


def fair_probs(book_prices):
    """Median de-vigged consensus across books quoting both sides."""
    pairs = [devig_pair(p1, p2) for _, p1, p2, _ in book_prices if p1 and p2]
    pairs = [p for p in pairs if p]
    if len(pairs) < 2:
        return None, None, len(pairs)
    return median(p[0] for p in pairs), median(p[1] for p in pairs), len(pairs)


def correct_flips(book_prices):
    """Some books list outcomes in the opposite order; detect and swap."""
    rows = [(i, p1, p2) for i, (_, p1, p2, _) in enumerate(book_prices) if p1 and p2]
    if len(rows) < 4:
        return book_prices
    shares = [implied(p1) / (implied(p1) + implied(p2)) for _, p1, p2 in rows]
    cons = median(shares)
    out = list(book_prices)
    for (i, p1, p2), s in zip(rows, shares):
        if abs((1 - s) - cons) + 0.04 < abs(s - cons):
            label, _, _, kind = out[i]
            out[i] = (label, p2, p1, kind)
    return out


def slip(odds):
    return 1 + (odds - 1) * (1 - SLIPPAGE)


def entry_fee(slug, stake, odds):
    """Prediction-market fee: charged on entry, win or lose."""
    for key, coeff in PREDICTION_COEFF.items():
        if key in slug.lower():
            return coeff * stake * (odds - 1) / odds
    return 0.0


def kelly(odds, p):
    b = odds - 1
    if b <= 0:
        return 0.0, 0.0
    f = max(0.0, (b * p - (1 - p)) / b)
    growth = (p * __import__("math").log(1 + b * f) + (1 - p) * __import__("math").log(1 - f)) if 0 < f < 1 else 0.0
    return f, growth


# ----------------------------------------------------------------- edge validation
# A price that looks like edge is often something else: a stale line on a
# suspended market, a broken feed, or a "consensus" made of books that all copy
# each other. These checks try to separate real edge from artefact.

# Books under common ownership don't price independently, so they shouldn't each
# count as a separate confirming voice in a consensus.
BOOK_GROUPS = {
    "Betfair Exchange": "flutter", "Betfair SP": "flutter", "Paddy Power": "flutter",
    "Sky Bet": "flutter",
    "Ladbrokes": "entain", "Coral": "entain", "Betdaq": "entain", "Sportingbet": "entain",
    "William Hill": "evoke", "888sport": "evoke", "Mr Green": "evoke",
    "Unibet": "kindred", "Unibet UK": "kindred",
    "BetVictor": "betvictor", "Virgin Bet": "betvictor",  # Virgin runs on BetVictor's platform
    "Pinnacle": "pinnacle", "Smarkets": "smarkets", "Matchbook": "matchbook",
    "Kalshi": "kalshi", "Polymarket": "polymarket", "Betway": "betway",
    "DraftKings": "draftkings", "Betfred": "betfred", "BoyleSports": "boylesports",
    "Grosvenor": "grosvenor", "Spreadex": "spreadex", "PokerStars": "pokerstars",
}

MIN_INDEPENDENT_GROUPS = int(_setting("MIN_INDEPENDENT_GROUPS", 3))
MAX_CREDIBLE_EV = float(_setting("MAX_CREDIBLE_EV", 15.0))
MAX_CREDIBLE_ARB = float(_setting("MAX_CREDIBLE_ARB", 10.0))
MIN_FAIR_PROB = 0.05           # EV estimates get unreliable at the extremes
MAX_FAIR_PROB = 0.95
MAX_OUTLIER_SIGMA = 3.5        # how far from the pack before a price is suspect
# ...but sigma alone is misleading. When books cluster tightly the standard
# deviation is tiny, so ANY better price reads as many sigma out - which would
# reject exactly the genuine edges we're looking for. A price must also differ
# by a meaningful absolute amount before we call it stale. Real edge is worth
# 1-3 percentage points of implied probability; a stale line is usually 10+.
MIN_OUTLIER_ABS_PP = 0.07      # 7 percentage points of implied probability


def _is_outlier(candidate_prob, peer_probs):
    """True only if a price is both statistically AND materially out of line."""
    if len(peer_probs) < 3:
        return False, 0.0
    sd = _stdev(peer_probs)
    mean = sum(peer_probs) / len(peer_probs)
    abs_gap = abs(candidate_prob - mean)
    if abs_gap < MIN_OUTLIER_ABS_PP:
        return False, 0.0
    if sd <= 0:
        return True, 99.0
    sigma = abs_gap / sd
    return sigma > MAX_OUTLIER_SIGMA, sigma


def group_of(label):
    return BOOK_GROUPS.get(label, label.lower())


def independent_groups(labels):
    return len({group_of(l) for l in labels})


def _stdev(xs):
    if len(xs) < 2:
        return 0.0
    m = sum(xs) / len(xs)
    return (sum((x - m) ** 2 for x in xs) / (len(xs) - 1)) ** 0.5


def fair_excluding(book_prices, exclude_label):
    """
    Consensus fair probabilities computed WITHOUT the book being judged.

    This matters: if a book's own price helps set the 'fair' value, it drags that
    value toward itself, and the measured edge is partly circular.
    """
    pairs = []
    for lbl, p1, p2, _kind in book_prices:
        if lbl == exclude_label or not (p1 and p2):
            continue
        d = devig_pair(p1, p2)
        if d:
            pairs.append(d)
    if len(pairs) < 2:
        return None, None, 0
    return median(p[0] for p in pairs), median(p[1] for p in pairs), len(pairs)


def validate_edge(book_prices, label, odds, side_idx):
    """
    Decide whether an apparent edge is credible.
    side_idx: 1 for participant 1, 2 for participant 2.

    Returns (is_valid, honest_ev_pct, honest_fair, reason).
    The EV returned is recomputed against a leave-one-out consensus, so it is
    usually smaller - and more truthful - than the naive figure.
    """
    others = [lbl for lbl, p1, p2, _ in book_prices if lbl != label and p1 and p2]
    n_groups = independent_groups(others)
    if n_groups < MIN_INDEPENDENT_GROUPS:
        return False, None, None, f"only {n_groups} independent book group(s) to compare against"

    f1, f2, _n = fair_excluding(book_prices, label)
    if f1 is None:
        return False, None, None, "not enough books quoting both sides"
    fair = f1 if side_idx == 1 else f2

    if not (MIN_FAIR_PROB <= fair <= MAX_FAIR_PROB):
        return False, None, fair, f"fair probability {fair*100:.1f}% too extreme to trust"

    ev = (odds * fair - 1) * 100
    if ev <= 0:
        return False, ev, fair, "edge vanishes once this book is excluded from its own consensus"

    if ev > MAX_CREDIBLE_EV:
        return False, ev, fair, (f"{ev:.1f}% EV is implausibly large - almost certainly a "
                                 f"stale or erroneous price")

    # outlier test against the rest of the pack on this side
    peers = [1 / (p1 if side_idx == 1 else p2)
             for lbl, p1, p2, _ in book_prices
             if lbl != label and (p1 if side_idx == 1 else p2)]
    is_out, sigma = _is_outlier(1 / odds, peers)
    if is_out:
        return False, ev, fair, (f"price sits {sigma:.1f} SDs and >7pp from the other "
                                 f"books - likely stale")

    # cross-check against the sharpest book on the board
    notes = [f"{n_groups} independent groups"]
    sharp = next(((p1, p2) for lbl, p1, p2, _ in book_prices
                  if lbl == "Pinnacle" and p1 and p2), None)
    if sharp:
        d = devig_pair(*sharp)
        if d:
            sf = d[0] if side_idx == 1 else d[1]
            sev = (odds * sf - 1) * 100
            if sev <= 0:
                return False, ev, fair, "Pinnacle's price says there is no edge here"
            notes.append(f"Pinnacle agrees ({sev:+.1f}%)")
    else:
        notes.append("no Pinnacle cross-check")

    return True, ev, fair, "; ".join(notes)


def validate_arb(book_prices, leg1, leg2, gross_pct):
    """The same scepticism applied to arbitrage."""
    if gross_pct > MAX_CREDIBLE_ARB:
        return False, (f"{gross_pct:.1f}% arb is implausibly large - one leg is almost "
                       f"certainly stale or mispriced")
    labels = [lbl for lbl, p1, p2, _ in book_prices if p1 and p2]
    if independent_groups(labels) < MIN_INDEPENDENT_GROUPS:
        return False, "too few independent books to trust these prices"
    if group_of(leg1["book"]) == group_of(leg2["book"]):
        return False, f"both legs sit with the same operator ({group_of(leg1['book'])})"
    for leg, idx in ((leg1, 1), (leg2, 2)):
        peers = [1 / (p1 if idx == 1 else p2)
                 for lbl, p1, p2, _ in book_prices
                 if lbl != leg["book"] and (p1 if idx == 1 else p2)]
        is_out, sigma = _is_outlier(1 / leg["odds"], peers)
        if is_out:
            return False, (f"{leg['book']} price is {sigma:.1f} SDs and >7pp out of line "
                           f"- likely stale")
    return True, "legs independent, prices within normal dispersion"


def analyse(book_prices, p1_name, p2_name):
    """Return (arb_dict_or_None, list_of_validated_value_bets)."""
    book_prices = correct_flips(book_prices)
    f1, f2, n = fair_probs(book_prices)
    if f1 is None or n < MIN_BOOKS_FOR_CONSENSUS:
        return None, []

    side1 = [(lbl, p1, kind) for lbl, p1, _, kind in book_prices if p1]
    side2 = [(lbl, p2, kind) for lbl, _, p2, kind in book_prices if p2]

    arb = None
    if side1 and side2:
        b1 = max(side1, key=lambda x: x[1])
        b2 = max(side2, key=lambda x: x[1])
        over = 1 / b1[1] + 1 / b2[1]
        if over < 1:
            gross = (1 / over - 1) * 100
            leg1 = {"book": b1[0], "odds": b1[1], "kind": b1[2], "sel": p1_name}
            leg2 = {"book": b2[0], "odds": b2[1], "kind": b2[2], "sel": p2_name}
            ok, reason = validate_arb(book_prices, leg1, leg2, gross)
            if ok:
                arb = {"profit_pct": gross, "leg1": leg1, "leg2": leg2, "validation": reason}
            else:
                log(f"  arb rejected ({gross:.2f}%): {reason}", "info")

    values = []
    for side_idx, side in ((1, side1), (2, side2)):
        sel = p1_name if side_idx == 1 else p2_name
        naive_fair = f1 if side_idx == 1 else f2
        for lbl, odds, kind in side:
            if odds * naive_fair - 1 <= 0:
                continue                      # cheap filter before the real test
            ok, ev, fair, reason = validate_edge(book_prices, lbl, odds, side_idx)
            if not ok:
                log(f"  edge rejected ({lbl} {sel}): {reason}", "info")
                continue
            f, g = kelly(odds, fair)
            values.append({"book": lbl, "sel": sel, "odds": odds, "fair": fair,
                           "ev_pct": ev, "kelly": f, "growth": g, "kind": kind,
                           "validation": reason})

    values.sort(key=lambda v: v["growth"], reverse=True)
    if values:
        best_side = values[0]["sel"]
        values = [v for v in values if v["sel"] == best_side]
    return arb, values


# ----------------------------------------------------------------- ledger
# openpyxl writes formulas but never calculates them, so after the scanner saves
# the file every cached formula value is gone and data_only reads come back as
# None. Anything the script needs to KNOW (capital, P&L) is therefore computed
# here in Python, mirroring the spreadsheet's own formulas. Excel still shows
# the same numbers when you open it - this is only about what the script reads.

def _row_net_pnl(odds, stake, result, venue, venue_kind):
    """Net P&L for one settled position, after commission and entry fees."""
    if not result or odds is None or stake is None:
        return None
    res = str(result).strip().lower()
    venue_l = str(venue or "").lower()
    kind = str(venue_kind or "").lower()

    entry = 0.0
    if kind == "prediction":
        coeff = 0.07 if "kalshi" in venue_l else 0.05
        entry = coeff * stake * (odds - 1) / odds

    if res == "won":
        gross = stake * (odds - 1)
        commission = 0.0
        if kind == "exchange":
            rate = 0.05 if "betfair" in venue_l else 0.02
            commission = rate * gross
        return gross - commission - entry
    if res == "lost":
        return -stake - entry
    if res == "void":
        return -entry
    return None


def read_positions(ws):
    """Every logged position, with P&L computed rather than read from cache."""
    out = []
    for r in range(6, 106):
        if not ws.cell(r, 4).value:
            continue
        odds = ws.cell(r, 9).value
        stake = ws.cell(r, 11).value
        odds = odds if isinstance(odds, (int, float)) else None
        stake = stake if isinstance(stake, (int, float)) else None
        rec = {
            "row": r, "start": ws.cell(r, 3).value, "market": ws.cell(r, 4).value,
            "strategy": ws.cell(r, 5).value, "venue": ws.cell(r, 6).value,
            "kind": ws.cell(r, 7).value, "sel": ws.cell(r, 8).value,
            "odds": odds, "stake": stake, "result": ws.cell(r, 12).value,
            "how": ws.cell(r, 29).value,
        }
        rec["net"] = _row_net_pnl(odds, stake, rec["result"], rec["venue"], rec["kind"])
        out.append(rec)
    return out


def open_blotter():
    from openpyxl import load_workbook
    wb = load_workbook(LEDGER)
    return wb, wb["Trade Blotter"]


def current_capital(ws):
    """Starting capital plus realised P&L. Computed, not read from a stale cache."""
    realised = sum(p["net"] for p in read_positions(ws) if p["net"] is not None)
    return STARTING_CAPITAL + realised


def open_exposure(ws):
    total = 0.0
    for r in range(6, 106):
        if ws.cell(r, 4).value and not ws.cell(r, 12).value:
            stake = ws.cell(r, 11).value
            if isinstance(stake, (int, float)):
                total += stake
    return total


def next_row(ws):
    for r in range(6, 106):
        if not ws.cell(r, 4).value:
            return r
    return None


def append_position(ws, row, pos):
    """Write only input columns A-L; M-AA are pre-built formulas."""
    ws.cell(row, 1, row - 5)
    ws.cell(row, 2, dt.date.today().isoformat())
    ws.cell(row, 3, pos["event_start"])
    ws.cell(row, 4, pos["market"])
    ws.cell(row, 5, pos["strategy"])
    ws.cell(row, 6, pos["venue"])
    ws.cell(row, 7, pos["venue_kind"])
    ws.cell(row, 8, pos["selection"])
    ws.cell(row, 9, round(pos["odds"], 4))
    ws.cell(row, 10, round(pos["fair"], 4) if pos.get("fair") else None)
    ws.cell(row, 11, round(pos["stake"], 2))
    # column 12 (Result) left blank - filled by settle_positions()
    ws.cell(row, 28, pos.get("fixture_id", ""))          # metadata for settlement


# ----------------------------------------------------------------- settlement
# Result strings vary by feed. Anything not recognised is left UNSETTLED and
# reported, rather than guessed - a wrong settlement silently corrupts the P&L.
WON_TOKENS = {"won", "win", "winner", "w", "1", "true", "yes", "settled_won"}
LOST_TOKENS = {"lost", "lose", "loser", "l", "0", "false", "no", "settled_lost"}
VOID_TOKENS = {"void", "voided", "push", "cancelled", "canceled", "refund", "n/a"}


def classify_result(raw):
    """-> 'won' | 'lost' | 'void' | None (unrecognised)"""
    if raw is None:
        return None
    s = str(raw).strip().lower()
    if s in WON_TOKENS:
        return "won"
    if s in LOST_TOKENS:
        return "lost"
    if s in VOID_TOKENS:
        return "void"
    return None


def settlement_for_selection(payload, selection, p1_name, p2_name):
    """
    Map a settlements payload onto our recorded selection.

    Returns ('won'|'lost'|'void', reason) or (None, reason) when the mapping
    is not unambiguous. Ambiguity always yields None.
    """
    markets = payload.get("markets") or {}
    if not markets:
        return None, "no markets in settlement payload"

    # Prefer the match-winner market (lowest market id is the main 2-way line)
    for _mid, market in sorted(markets.items(), key=lambda kv: str(kv[0])):
        outcomes = market.get("outcomes") or {}
        if len(outcomes) < 2:
            continue

        graded = []
        for okey, oc in sorted(outcomes.items(), key=lambda kv: str(kv[0])):
            players = oc.get("players") or {}
            for p in players.values():
                r = classify_result(p.get("result"))
                name = p.get("playerName")
                graded.append((okey, name, r))
            if not players:
                graded.append((okey, None, classify_result(oc.get("result"))))

        if not graded or all(g[2] is None for g in graded):
            continue

        # Path 1: outcome carries a player name we can match directly
        sel = selection.strip().lower()
        named = [g for g in graded if g[1]]
        if named:
            hits = [g for g in named if sel in str(g[1]).strip().lower()
                    or str(g[1]).strip().lower() in sel]
            if len(hits) == 1 and hits[0][2]:
                return hits[0][2], f"matched on player name '{hits[0][1]}'"
            if len(hits) > 1:
                return None, "selection matched multiple outcomes - ambiguous"

        # Path 2: no names, but exactly two outcomes -> use positional order,
        # which must match the order used when the bet was recorded.
        if len(graded) == 2 and all(g[2] for g in graded):
            first_is_p1 = selection.strip().lower() == p1_name.strip().lower()
            second_is_p2 = selection.strip().lower() == p2_name.strip().lower()
            if first_is_p1:
                return graded[0][2], "positional map (outcome 1 = participant 1)"
            if second_is_p2:
                return graded[1][2], "positional map (outcome 2 = participant 2)"
            return None, "selection matches neither participant name"

    return None, "no gradable 2-way market found"


def settle_positions(state, ws, dry_run=False):
    """
    Grade any open position whose event has finished. Runs BEFORE scanning so
    new positions are sized off correctly-updated capital.
    Returns (settled_count, needs_manual_list).
    """
    now = dt.datetime.now(dt.timezone.utc)
    pending = []
    for r in range(6, 106):
        if not ws.cell(r, 4).value:
            continue
        if ws.cell(r, 12).value:          # already settled
            continue
        start_raw = ws.cell(r, 3).value
        if not start_raw:
            continue
        try:
            st = str(start_raw).replace("Z", "").replace("T", " ")[:16]
            start = dt.datetime.strptime(st, "%Y-%m-%d %H:%M").replace(tzinfo=dt.timezone.utc)
        except ValueError:
            continue
        # give the match time to actually finish before asking for a result
        if (now - start).total_seconds() < SETTLE_DELAY_HRS * 3600:
            continue
        pending.append((r, ws.cell(r, 28).value, ws.cell(r, 4).value, ws.cell(r, 8).value))

    if not pending:
        return 0, []

    log(f"settlement: {len(pending)} position(s) awaiting a result")
    settled, manual = 0, []
    # Both legs of an arb share a fixture - grade each fixture only once.
    # We go straight to /settlements: the presence of gradable data IS the
    # signal that the match finished. (/fixtures can't be queried by
    # fixtureId alone, so there's no cheap status check to make first.)
    settle_cache = {}

    for row, fid, market, selection in pending:
        if budget_left(state) <= SCAN_RESERVE and fid not in settle_cache:
            log("settlement: budget reserve reached, deferring the rest", "info")
            break
        if not fid:
            manual.append((row, market, selection, "no fixture ID recorded"))
            continue

        if fid not in settle_cache:
            try:
                settle_cache[fid] = get(f"/settlements?fixtureId={fid}", state)
            except RuntimeError as e:
                msg = str(e)
                # 404 usually just means "not settled yet", which isn't an error
                if "404" in msg:
                    settle_cache[fid] = {}
                else:
                    settle_cache[fid] = f"error:{msg}"
        payload = settle_cache[fid]

        if isinstance(payload, str):
            manual.append((row, market, selection, payload[6:]))
            continue

        if not payload or not (payload.get("markets") or {}):
            log(f"  not settled yet: {market}")
            continue

        parts = str(market).split(" vs ")
        p1 = parts[0].strip() if parts else ""
        p2 = parts[1].strip() if len(parts) > 1 else ""
        outcome, reason = settlement_for_selection(payload, str(selection), p1, p2)

        if outcome is None:
            manual.append((row, market, selection, reason))
            log(f"  NEEDS REVIEW: {market} - {reason}", "err")
            continue

        if not dry_run:
            ws.cell(row, 12, outcome)
            ws.cell(row, 29, f"auto: {reason}"[:60])
        log(f"  {outcome.upper()}: {market} ({selection})", "ok")
        settled += 1

    return settled, manual


def dump_settlement(fixture_id):
    """Print a raw settlement payload so the parsing can be verified once."""
    state = load_state()
    try:
        payload = get(f"/settlements?fixtureId={fixture_id}", state)
    except RuntimeError as e:
        print(f"Could not fetch settlements: {e}")
        print("If this is a 401/403, the settlements endpoint may not be on your plan.")
        print("Settlement will fall back to manual - fill column L yourself.")
        save_state(state)
        return
    save_state(state)
    print(json.dumps(payload, indent=2)[:4000])
    print("\n--- parsed result tokens found ---")
    for _mid, market in (payload.get("markets") or {}).items():
        for okey, oc in (market.get("outcomes") or {}).items():
            for p in (oc.get("players") or {}).values():
                print(f"  outcome {okey}: playerName={p.get('playerName')!r} "
                      f"result={p.get('result')!r} -> {classify_result(p.get('result'))}")


# ----------------------------------------------------------------- scan
def priority(fixture):
    st = fixture.get("startTime")
    if not st:
        return 0.05
    try:
        start = dt.datetime.fromisoformat(st.replace("Z", "+00:00"))
    except ValueError:
        return 0.05
    hrs = (start - dt.datetime.now(dt.timezone.utc)).total_seconds() / 3600
    if hrs <= SKIP_INSIDE_MIN / 60:
        return 0.0
    if hrs <= PRIORITY_WINDOW_HRS:
        return 1 / (0.5 + hrs)
    if hrs <= 12:
        return 0.10
    if hrs <= 24:
        return 0.04
    return 0.01


def parse_odds_payload(payload):
    """-> [(label, odds_side1, odds_side2, kind)]"""
    out = []
    for slug, bm in (payload.get("bookmakerOdds") or {}).items():
        meta = BM_META.get(slug)
        if not meta:
            continue
        label, kind = meta
        markets = bm.get("markets") or {}
        if not markets:
            continue
        market = list(markets.values())[0]
        outcomes = market.get("outcomes") or {}
        prices = []
        for key, oc in sorted(outcomes.items(), key=lambda kv: str(kv[0])):
            players = oc.get("players") or {}
            active = [p for p in players.values() if p.get("active") is not False]
            if active and active[0].get("price"):
                prices.append(float(active[0]["price"]))
        if prices:
            out.append((label, prices[0], prices[1] if len(prices) > 1 else None, kind))
    return out


def venue_slug(label):
    for slug, (lbl, _) in BM_META.items():
        if lbl == label:
            return slug
    return label.lower()


def run(dry_run=False):
    state = load_state()
    left = budget_left(state)
    if left <= 0:
        log(f"daily budget of {DAILY_REQUEST_BUDGET} already spent - nothing to do", "info")
        return
    if not TRACKED:
        log("No tournaments configured yet.", "err")
        log("Run:  python scanner.py --list-tournaments 12", "err")
        log("Then paste the ones you want into config.json", "err")
        return

    log(f"budget: {left} requests available today")

    # --- settle finished positions FIRST, so new stakes size off correct capital
    wb = ws = None
    manual_review = []
    if not dry_run:
        writable, why = _check_writable(LEDGER)
        if not writable:
            log(why, "err")
            return
        wb, ws = open_blotter()
        settled, manual_review = settle_positions(state, ws, dry_run=False)
        if settled:
            wb.save(LEDGER)
            log(f"settled {settled} position(s)", "ok")
            wb, ws = open_blotter()   # reload so capital reflects the settlements
        if manual_review:
            log(f"{len(manual_review)} position(s) need manual settlement:", "err")
            for row, market, sel, why in manual_review:
                log(f"    row {row}: {market} ({sel}) - {why}", "err")

    if budget_left(state) <= 0:
        log("budget spent on settlement - no scanning this run", "info")
        if not dry_run and wb is not None:
            wb.save(LEDGER)
        save_state(state)
        return

    # --- gather candidate fixtures
    candidates = []
    for label, tid in TRACKED.items():
        if budget_left(state) <= 1:
            break
        try:
            data = get(f"/fixtures?tournamentId={tid}&statusId=0&language=en", state)
        except RuntimeError as e:
            log(f"fixtures failed for {label}: {e}", "err")
            continue
        fixtures = data if isinstance(data, list) else (data.get("fixtures") or data.get("data") or [])
        for f in fixtures:
            p1, p2 = f.get("participant1Name"), f.get("participant2Name")
            if not p1 or not p2:
                continue
            if any(t in f"{p1}{p2}".lower() for t in ("tbd", "qualifier", "winner of")):
                continue
            if f.get("hasOdds") is False:
                continue
            candidates.append(f)

    # --- prioritise
    scored = []
    for f in candidates:
        fid = str(f.get("fixtureId") or f.get("id"))
        p = priority(f)
        if p <= 0:
            continue
        last = state["last_scan"].get(fid)
        if last and (time.time() - last) < RESCAN_COOLDOWN_MIN * 60:
            continue
        scored.append((p, fid, f))
    scored.sort(key=lambda x: x[0], reverse=True)

    if not scored:
        log("nothing in the priority window right now", "info")
        save_state(state)
        return

    log(f"{len(scored)} fixtures in window; scanning top {min(budget_left(state), len(scored))}")

    wb = ws = None
    if not dry_run:
        wb, ws = open_blotter()
        capital = current_capital(ws)
        exposure = open_exposure(ws)
        log(f"capital £{capital:,.2f} | open exposure £{exposure:,.2f}")
    else:
        capital, exposure = STARTING_CAPITAL, 0.0

    found = 0
    for score, fid, f in scored:
        if budget_left(state) <= 0:
            log("budget exhausted mid-scan", "info")
            break
        try:
            payload = get(f"/odds?fixtureId={fid}&oddsFormat=decimal&verbosity=3", state)
        except RuntimeError as e:
            log(f"odds failed for {fid}: {e}", "err")
            continue
        state["last_scan"][fid] = time.time()

        p1 = (f.get("participant1Name") or "?").split(",")[0]
        p2 = (f.get("participant2Name") or "?").split(",")[0]
        books = parse_odds_payload(payload)
        if len(books) < MIN_BOOKS_FOR_CONSENSUS:
            log(f"thin market ({len(books)} books): {p1} vs {p2}")
            continue

        arb, values = analyse(books, p1, p2)
        match = f"{p1} vs {p2}"
        start = (f.get("startTime") or "")[:16].replace("T", " ")

        if exposure >= capital * MAX_EXPOSURE_PCT:
            log("max exposure reached - not opening new positions", "info")
            break

        positions = []
        if arb:
            stake = min(capital * ARB_PCT, ARB_CAP)
            o1, o2 = slip(arb["leg1"]["odds"]), slip(arb["leg2"]["odds"])
            tot = 1 / o1 + 1 / o2
            for leg, o in ((arb["leg1"], o1), (arb["leg2"], o2)):
                positions.append({
                    "key": f"{fid}|arb|{leg['book']}|{leg['sel']}",
                    "market": match, "strategy": "ARB", "venue": leg["book"],
                    "venue_kind": leg["kind"], "selection": leg["sel"],
                    "odds": o, "fair": None, "fixture_id": fid,
                    "stake": stake * ((1 / o) / tot), "event_start": start,
                })
            log(f"ARB {arb['profit_pct']:.2f}% gross: {match}", "ok")
        elif values:
            top = values[0]
            stake = min(capital * top["kelly"] * KELLY_FRACTION, capital * EV_CAP_PCT)
            if stake >= 1:
                positions.append({
                    "key": f"{fid}|ev|{top['book']}|{top['sel']}",
                    "market": match, "strategy": "VALUE", "venue": top["book"],
                    "venue_kind": top["kind"], "selection": top["sel"],
                    "odds": slip(top["odds"]), "fair": top["fair"], "fixture_id": fid,
                    "stake": stake, "event_start": start,
                    "validation": top.get("validation", ""),
                })
                log(f"+EV {top['ev_pct']:.1f}% ({top['book']}): {match}", "ok")

        for pos in positions:
            if pos["key"] in state["logged"]:
                continue
            if dry_run:
                log(f"  [dry-run] would log {pos['strategy']} {pos['selection']} "
                    f"@ {pos['odds']:.2f} £{pos['stake']:.2f} ({pos['venue']})")
                found += 1
                continue
            row = next_row(ws)
            if row is None:
                log("blotter is full (100 rows) - extend it or archive", "err")
                break
            append_position(ws, row, pos)
            state["logged"].append(pos["key"])
            exposure += pos["stake"]
            found += 1


    if not dry_run and wb is not None:
        wb.save(LEDGER)
        log(f"saved {LEDGER}", "ok")
    save_state(state)
    log(f"run complete - {found} position(s) logged, {budget_left(state)} requests left today", "ok")


def check():
    """Verify the setup before anything else is attempted."""
    ok = True
    print(f"Checking your setup...  (scanner.py {VERSION})\n")

    print(f"  config.json    : {_CONFIG_PATH}")
    if os.path.exists(_CONFIG_PATH):
        print("                   found")
    else:
        print("                   NOT FOUND - create it next to scanner.py")
        ok = False

    if API_KEY:
        print(f"  API key        : found ({API_KEY[:8]}...)")
    else:
        print("  API key        : MISSING - add ODDSPAPI_KEY to config.json")
        ok = False

    if TRACKED:
        print(f"  Tournaments    : {len(TRACKED)} tracked -> {', '.join(list(TRACKED)[:3])}")
    else:
        print("  Tournaments    : none yet - run --list-tournaments 12")
        ok = False

    print(f"  Spreadsheet    : {LEDGER}")
    if os.path.exists(LEDGER):
        try:
            from openpyxl import load_workbook
            wb = load_workbook(LEDGER)
            if "Trade Blotter" in wb.sheetnames:
                print("                   found, Trade Blotter tab present")
            else:
                print("                   found, but no 'Trade Blotter' tab - wrong file?")
                ok = False
        except ImportError:
            print("                   openpyxl not installed - run: pip install openpyxl")
            ok = False
        except Exception as e:
            print(f"                   could not open: {e}")
            ok = False
    else:
        print("                   NOT FOUND - put the .xlsx next to scanner.py")
        ok = False

    print(f"  Daily budget   : {DAILY_REQUEST_BUDGET} requests")
    print()
    print("All good - you can run the scanner." if ok else "Fix the items above, then run --check again.")
    return ok


def _check_writable(path):
    """Windows locks a file while Excel has it open. Detect that up front."""
    if not os.path.exists(path):
        return True, ""
    try:
        with open(path, "a+b"):
            pass
        return True, ""
    except PermissionError:
        return False, (
            f"Cannot write to {os.path.basename(path)} - it looks like it's open in Excel.\n"
            "        Close the spreadsheet in Excel, then run this again.\n"
            "        (Windows locks the file while Excel has it open.)")
    except OSError as e:
        return False, f"Cannot write to {os.path.basename(path)}: {e}"


def reset_ledger(force=False):
    """Clear every logged position and start fresh from £5,000."""
    import shutil

    print(f"Reset the paper trading ledger  (scanner.py {VERSION})\n")

    if not os.path.exists(LEDGER):
        print(f"  Spreadsheet not found at {LEDGER}")
        return

    writable, why = _check_writable(LEDGER)
    if not writable:
        print(f"  {why}")
        return

    from openpyxl import load_workbook
    wb = load_workbook(LEDGER)
    if "Trade Blotter" not in wb.sheetnames:
        print("  No 'Trade Blotter' tab - is this the right file?")
        return
    ws = wb["Trade Blotter"]

    filled = sum(1 for r in range(6, 106) if ws.cell(r, 4).value)
    state = load_state()
    logged = len(state.get("logged", []))

    print(f"  Spreadsheet : {LEDGER}")
    print(f"  Positions   : {filled} rows will be cleared")
    print(f"  Scan memory : {logged} logged keys will be forgotten")
    print(f"  Capital     : reset to the starting figure on the Assumptions tab")
    print()

    if not force:
        print("  A timestamped backup is taken first.")
        answer = input("  Type RESET to confirm, or anything else to cancel: ").strip()
        if answer != "RESET":
            print("\n  Cancelled - nothing changed.")
            return

    # --- back up first
    stamp = dt.datetime.now().strftime("%Y-%m-%d_%H%M")
    backup = os.path.join(os.path.dirname(LEDGER) or ".",
                          f"backup-ledger-{stamp}.xlsx")
    try:
        shutil.copy2(LEDGER, backup)
        print(f"\n  Backup saved: {os.path.basename(backup)}")
    except Exception as e:
        print(f"\n  Could not create a backup ({e}) - stopping to be safe.")
        return

    # --- clear input + metadata columns; formulas in M:AA stay intact
    for r in range(6, 106):
        for c in list(range(1, 13)) + [28, 29]:
            ws.cell(r, c).value = None
    wb.save(LEDGER)
    print(f"  Cleared {filled} position(s) from the blotter")

    # --- forget scan history so opportunities can be logged again
    fresh = {"budget": state.get("budget", {}), "last_scan": {}, "logged": []}
    save_state(fresh)
    print("  Cleared scan memory (today's request count kept)")

    print("\n  Done. Run 'python scanner.py' to start logging fresh.\n")


def status():
    """Full picture: capital, open positions, and how settled ones resolved."""
    state = load_state()
    print(f"\nPaper trading status   (scanner.py {VERSION})")
    print("=" * 62)

    try:
        wb, ws = open_blotter()
        positions = read_positions(ws)
    except Exception as e:
        print(f"  Could not read the spreadsheet: {e}\n")
        return

    open_rows = [p for p in positions if not p["result"]]
    settled_rows = [p for p in positions if p["result"]]

    # ---- capital
    cap = current_capital(ws)
    pnl = cap - STARTING_CAPITAL
    at_risk = sum(p["stake"] or 0 for p in open_rows)
    print(f"  Capital        : £{cap:,.2f}   ({pnl:+,.2f} since inception)")
    print(f"  At risk now    : £{at_risk:,.2f} across {len(open_rows)} open position(s)")
    print(f"  Requests today : {budget_left(state)}/{DAILY_REQUEST_BUDGET} remaining")

    # ---- open positions
    print("\n" + "-" * 62)
    print(f"  OPEN POSITIONS ({len(open_rows)})")
    print("-" * 62)
    if not open_rows:
        print("  Nothing open.")
    else:
        now = dt.datetime.now(dt.timezone.utc)
        for p in open_rows:
            when = ""
            if p["start"]:
                try:
                    st = str(p["start"]).replace("Z", "").replace("T", " ")[:16]
                    d = dt.datetime.strptime(st, "%Y-%m-%d %H:%M").replace(tzinfo=dt.timezone.utc)
                    hrs = (d - now).total_seconds() / 3600
                    if hrs > 0:
                        when = f"starts in {hrs:.1f}h"
                    elif hrs > -SETTLE_DELAY_HRS:
                        when = "in play"
                    else:
                        when = f"finished {abs(hrs):.0f}h ago - awaiting result"
                except ValueError:
                    when = str(p["start"])
            print(f"  row {p['row']:<3} {str(p['market'])[:30]:<30} {str(p['strategy']):<6}")
            print(f"         {str(p['sel'])[:18]:<18} @ {p['odds']:<6} "
                  f"£{p['stake']:<8,.2f} {p['venue']}")
            if when:
                print(f"         {when}")

    # ---- settled positions
    print("\n" + "-" * 62)
    print(f"  SETTLED POSITIONS ({len(settled_rows)})")
    print("-" * 62)
    if not settled_rows:
        print("  Nothing settled yet.")
    else:
        for p in settled_rows[-15:]:
            res = str(p["result"]).upper()
            net = p["net"]
            netstr = f"{net:+,.2f}" if net is not None else "  --  "
            auto = " [auto]" if p["how"] and str(p["how"]).startswith("auto") else " [manual]"
            print(f"  row {p['row']:<3} {str(p['market'])[:28]:<28} "
                  f"{str(p['sel'])[:14]:<14} {res:<5} £{netstr:>10}{auto}")
        if len(settled_rows) > 15:
            print(f"  ... and {len(settled_rows)-15} earlier. Open the spreadsheet for the full record.")

        won = sum(1 for p in settled_rows if str(p["result"]).lower() == "won")
        lost = sum(1 for p in settled_rows if str(p["result"]).lower() == "lost")
        void = sum(1 for p in settled_rows if str(p["result"]).lower() == "void")
        realised = sum(p["net"] or 0 for p in settled_rows)
        print(f"\n  Won {won} | Lost {lost} | Void {void}"
              + (f" | strike rate {won/(won+lost)*100:.0f}%" if (won + lost) else ""))
        print(f"  Realised P&L   : £{realised:+,.2f}")
        if won + lost < 30:
            print(f"  NOTE: {won+lost} settled bets is far too small a sample to judge")
            print("        whether the strategy works. Treat these numbers as noise.")

    # ---- anything needing you
    stale = [p for p in open_rows if p["start"] and _finished_long_ago(p["start"])]
    if stale:
        print("\n" + "-" * 62)
        print(f"  NEEDS YOUR ATTENTION ({len(stale)})")
        print("-" * 62)
        print("  These finished but could not be graded automatically.")
        print("  Put won / lost / void in column L of the spreadsheet:\n")
        for p in stale:
            print(f"    row {p['row']}: {p['market']} - {p['sel']}")
    print()


def _finished_long_ago(start_val, hours=6):
    try:
        st = str(start_val).replace("Z", "").replace("T", " ")[:16]
        d = dt.datetime.strptime(st, "%Y-%m-%d %H:%M").replace(tzinfo=dt.timezone.utc)
        return (dt.datetime.now(dt.timezone.utc) - d).total_seconds() / 3600 > hours
    except ValueError:
        return False


def list_tournaments(sport_id):
    state = load_state()
    data = get(f"/tournaments?sportId={sport_id}&language=en", state)
    raw = data if isinstance(data, list) else (data.get("tournaments") or data.get("data") or [])
    for t in sorted(raw, key=lambda x: -(x.get("upcomingFixtures", 0) + x.get("futureFixtures", 0)))[:40]:
        n = (t.get("tournamentName") or t.get("name") or "").strip()
        cnt = t.get("upcomingFixtures", 0) + t.get("futureFixtures", 0)
        if cnt:
            print(f'  "{n}": {t.get("tournamentId")},   # {cnt} fixtures')
    save_state(state)


def _dispatch(args):
    if args.check:
        check()
    elif args.test_key:
        test_key()
    elif args.reset:
        reset_ledger(force=args.yes)
    elif args.status:
        status()
    elif args.verify_settlement:
        dump_settlement(args.verify_settlement)
    elif args.settle_only:
        st = load_state()
        wbk, wsx = open_blotter()
        n, manual = settle_positions(st, wsx)
        wbk.save(LEDGER)
        save_state(st)
        log(f"settled {n}; {len(manual)} need manual review", "ok")
        for row, market, sel, why in manual:
            log(f"    row {row}: {market} ({sel}) - {why}", "err")
    elif args.list_tournaments:
        list_tournaments(args.list_tournaments)
    else:
        run(dry_run=args.dry_run)


if __name__ == "__main__":

    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true", help="scan and report, write nothing")
    ap.add_argument("--status", action="store_true", help="show budget and open positions")
    ap.add_argument("--check", action="store_true", help="verify setup is correct")
    ap.add_argument("--test-key", action="store_true", help="test the API key directly")
    ap.add_argument("--reset", action="store_true",
                    help="clear all logged positions and start fresh (backs up first)")
    ap.add_argument("--yes", action="store_true", help="skip the confirmation prompt")
    ap.add_argument("--version", action="version", version=f"scanner.py {VERSION}")
    ap.add_argument("--list-tournaments", type=int, metavar="SPORT_ID",
                    help="list tournament IDs (12=tennis, 13=MLB, 11=basketball)")
    ap.add_argument("--settle-only", action="store_true",
                    help="grade finished positions, skip scanning")
    ap.add_argument("--verify-settlement", metavar="FIXTURE_ID",
                    help="dump a raw settlement payload to check result parsing")
    args = ap.parse_args()

    try:
        _dispatch(args)
    except RuntimeError as e:
        print(f"\n[!] {e}\n")
        sys.exit(1)
    except KeyboardInterrupt:
        print("\n[.] stopped")
        sys.exit(0)
