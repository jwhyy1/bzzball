<#
    Sets up the odds scanner to run automatically every 4 hours.

    HOW TO USE:
      1. Right-click this file
      2. Choose "Run with PowerShell"
      3. Answer the prompt

    It creates a Windows scheduled task called "Odds Scanner" that runs
    run-scanner.bat every 4 hours while your PC is on. Nothing needs to
    stay open.

    To undo everything later, run this again and choose Remove.
#>

$TaskName = "Odds Scanner"
$Folder   = $PSScriptRoot
$BatFile  = Join-Path $Folder "run-scanner.bat"

function Write-Head($text) {
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host " $text" -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host ""
}

Write-Head "Odds Scanner - automatic setup"

# ---------------------------------------------------------------- checks
Write-Host "Checking your setup..." -ForegroundColor White
Write-Host ""

$problems = @()

Write-Host -NoNewline "  Folder            : "
Write-Host $Folder -ForegroundColor Gray

Write-Host -NoNewline "  run-scanner.bat   : "
if (Test-Path $BatFile) {
    Write-Host "found" -ForegroundColor Green
} else {
    Write-Host "MISSING" -ForegroundColor Red
    $problems += "run-scanner.bat is not in this folder. Copy it in, next to scanner.py."
}

Write-Host -NoNewline "  scanner.py        : "
if (Test-Path (Join-Path $Folder "scanner.py")) {
    Write-Host "found" -ForegroundColor Green
} else {
    Write-Host "MISSING" -ForegroundColor Red
    $problems += "scanner.py is not in this folder."
}

Write-Host -NoNewline "  config.json       : "
if (Test-Path (Join-Path $Folder "config.json")) {
    Write-Host "found" -ForegroundColor Green
} else {
    Write-Host "MISSING" -ForegroundColor Red
    $problems += "config.json is not in this folder."
}

Write-Host -NoNewline "  spreadsheet       : "
if (Test-Path (Join-Path $Folder "paper-trading-ledger.xlsx")) {
    Write-Host "found" -ForegroundColor Green
} else {
    Write-Host "MISSING" -ForegroundColor Red
    $problems += "paper-trading-ledger.xlsx is not in this folder."
}

Write-Host -NoNewline "  Python            : "
$py = (Get-Command python -ErrorAction SilentlyContinue)
if ($py) {
    $ver = (& python --version 2>&1)
    Write-Host "$ver" -ForegroundColor Green
} else {
    Write-Host "NOT FOUND" -ForegroundColor Red
    $problems += "Python is not on your PATH. Reinstall from python.org and tick 'Add python.exe to PATH'."
}

if ($problems.Count -gt 0) {
    Write-Host ""
    Write-Host "Fix these first:" -ForegroundColor Red
    foreach ($p in $problems) { Write-Host "  - $p" -ForegroundColor Red }
    Write-Host ""
    Read-Host "Press Enter to close"
    exit 1
}

# ---------------------------------------------------------------- existing task
$existing = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue

Write-Host ""
if ($existing) {
    Write-Host "A task called '$TaskName' already exists." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  [R] Replace it with a fresh one"
    Write-Host "  [X] Remove it entirely (turn automation off)"
    Write-Host "  [C] Cancel, change nothing"
    Write-Host ""
    $choice = (Read-Host "Choose R, X or C").ToUpper()

    if ($choice -eq "C") { Write-Host "Nothing changed."; Read-Host "Press Enter to close"; exit 0 }

    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
    Write-Host "Removed the old task." -ForegroundColor Green

    if ($choice -eq "X") {
        Write-Host ""
        Write-Host "Automation is now off. Run this script again to switch it back on."
        Read-Host "Press Enter to close"
        exit 0
    }
} else {
    Write-Host "This will run the scanner automatically every 4 hours." -ForegroundColor White
    Write-Host "Your PC needs to be on, but nothing has to be open." -ForegroundColor Gray
    Write-Host ""
    $go = (Read-Host "Set it up now? (Y/N)").ToUpper()
    if ($go -ne "Y") { Write-Host "Cancelled."; Read-Host "Press Enter to close"; exit 0 }
}

# ---------------------------------------------------------------- create task
Write-Host ""
Write-Host "Creating the scheduled task..." -ForegroundColor White

try {
    $action = New-ScheduledTaskAction -Execute $BatFile -WorkingDirectory $Folder

    # first run 5 minutes from now, then every 4 hours indefinitely
    $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(5) `
                 -RepetitionInterval (New-TimeSpan -Hours 4)

    $settings = New-ScheduledTaskSettingsSet `
                  -AllowStartIfOnBatteries `
                  -DontStopIfGoingOnBatteries `
                  -StartWhenAvailable `
                  -ExecutionTimeLimit (New-TimeSpan -Minutes 30) `
                  -MultipleInstances IgnoreNew

    Register-ScheduledTask -TaskName $TaskName `
                           -Action $action `
                           -Trigger $trigger `
                           -Settings $settings `
                           -Description "Scans betting odds for arbitrage and +EV opportunities, settles finished bets, and logs to the paper trading ledger." `
                           | Out-Null

    Write-Host ""
    Write-Host "DONE - the scanner is now automated." -ForegroundColor Green
    Write-Host ""
    Write-Host "  Runs        : every 4 hours" -ForegroundColor Gray
    Write-Host "  First run   : in about 5 minutes" -ForegroundColor Gray
    Write-Host "  Results in  : paper-trading-ledger.xlsx" -ForegroundColor Gray
    Write-Host "  Activity log: scanner-log.txt" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  StartWhenAvailable is on, so if your PC is off at a scheduled" -ForegroundColor Gray
    Write-Host "  time, it catches up on the next start rather than skipping." -ForegroundColor Gray
    Write-Host ""

    $now = (Read-Host "Run it once right now to check it works? (Y/N)").ToUpper()
    if ($now -eq "Y") {
        Write-Host ""
        Write-Host "Running..." -ForegroundColor White
        Start-ScheduledTask -TaskName $TaskName
        Start-Sleep -Seconds 20
        $log = Join-Path $Folder "scanner-log.txt"
        if (Test-Path $log) {
            Write-Host ""
            Write-Host "--- last 25 lines of scanner-log.txt ---" -ForegroundColor Cyan
            Get-Content $log -Tail 25
            Write-Host "----------------------------------------" -ForegroundColor Cyan
        } else {
            Write-Host "No log yet - it may still be running. Check scanner-log.txt shortly." -ForegroundColor Yellow
        }
    }
}
catch {
    Write-Host ""
    Write-Host "Setup failed: $_" -ForegroundColor Red
    Write-Host ""
    Write-Host "Try right-clicking this file and choosing 'Run as administrator'." -ForegroundColor Yellow
}

Write-Host ""
Read-Host "Press Enter to close"
