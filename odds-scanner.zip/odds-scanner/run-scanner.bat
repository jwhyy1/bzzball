@echo off
REM ============================================================
REM  Odds scanner - automated run
REM  Triggered by Windows Task Scheduler every 4 hours.
REM  Everything it prints is appended to scanner-log.txt
REM ============================================================

cd /d "%~dp0"

echo. >> scanner-log.txt
echo ============================================================ >> scanner-log.txt
echo RUN STARTED: %date% %time% >> scanner-log.txt
echo ============================================================ >> scanner-log.txt

python scanner.py >> scanner-log.txt 2>&1

if errorlevel 1 (
    echo [!] RUN FAILED - see the error above >> scanner-log.txt
) else (
    echo [+] RUN COMPLETED OK >> scanner-log.txt
)

exit /b 0
