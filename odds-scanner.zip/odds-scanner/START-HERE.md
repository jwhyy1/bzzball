# Start Here

Paper-trading odds scanner. Finds arbitrage and positive-EV betting
opportunities across bookmakers, sizes hypothetical positions, and tracks
results in a spreadsheet. **No real money is involved.**

Full details are in `MANUAL.md`. This page gets you running.

---

## What's in this folder

| File | What it is |
|---|---|
| `scanner.py` | The scanner |
| `paper-trading-ledger.xlsx` | Your trading record, starts empty at £5,000 |
| `config.example.json` | Settings template — copy it to `config.json` |
| `MANUAL.md` | Full reference |
| `run-scanner.bat` | Used by the scheduler (optional) |
| `setup-automation.ps1` | Sets up scheduled running (optional) |

---

## Setup — about 10 minutes

### 1. Get your own API key

Sign up at **oddspapi.io** and generate a key. The free tier gives 250 requests
a month.

**Use your own key, not a shared one.** Two people on one key means you each
silently eat the other's monthly allowance, and neither of you can tell why
scans start failing.

### 2. Install Python

If `python --version` doesn't return 3.9 or higher, install from **python.org**
and tick **"Add python.exe to PATH"** during setup — it's easy to miss and
causes problems later.

### 3. Install the one dependency

```powershell
python -m pip install openpyxl
```

### 4. Create your config

Copy `config.example.json` and rename the copy to `config.json`. Open it in
Notepad and paste your key in:

```json
{
  "ODDSPAPI_KEY": "your-actual-key-here",
  "TRACKED_TOURNAMENTS": {},
  "DAILY_BUDGET": 8
}
```

### 5. Check it works

```powershell
cd path\to\odds-scanner
python scanner.py --check
```

Everything should say **found** except tournaments, which you set next.

### 6. Choose what to track

```powershell
python scanner.py --list-tournaments 12
```

(`12` tennis, `13` MLB, `11` basketball)

Pick two or three from the list and add them to `config.json`:

```json
  "TRACKED_TOURNAMENTS": {
    "Wimbledon": 2810,
    "Canadian Open": 2847
  },
```

Each tournament costs one request per run just to list its fixtures, so start
small.

### 7. Try it

```powershell
python scanner.py --dry-run
```

Reports what it finds, writes nothing. When that looks sensible:

```powershell
python scanner.py
```

---

## Everyday use

```powershell
python scanner.py            # settle finished bets, scan for new ones
python scanner.py --status   # capital, open positions, results
```

**Close Excel when you're done looking at the spreadsheet.** Windows locks the
file while it's open and the scanner can't write to it.

When `--status` shows anything under **NEEDS YOUR ATTENTION**, those are
finished matches it couldn't grade automatically. Put `won`, `lost`, or `void`
in column L of the spreadsheet.

---

## Two things worth knowing early

**Verify the settlement grading once.** Pick a settled row marked `[auto]`,
look up who actually won that match, and confirm the spreadsheet agrees. This is
the one part of the system that has never been tested against live data, and a
grading error would be invisible in the numbers while corrupting everything
downstream.

**Ignore short-run P&L.** With fewer than about 30 settled bets, the figure is
noise. Winning 60% of 15 bets is entirely normal with no edge at all — and so is
losing 60%. The first month tells you whether the machinery works, not whether
the strategy does.

---

## If you're running this alongside someone else

Keep separate ledgers. Two scanners writing to one spreadsheet produces
conflicting rows and nonsense capital figures. Run your own copy, then compare
results later — which is more interesting anyway, since you'll have two
independent samples rather than one muddled one.
